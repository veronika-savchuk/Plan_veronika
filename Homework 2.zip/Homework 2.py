class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return f'{self.name} каже: Гав-гав!'
    
class Cat(Animal):
    def speak(self):
        return f'{self.name} каже: Мяу!'

dog = Dog("Бобік")
cat = Cat("Мурчик")

print(dog.speak())  
print(cat.speak())

class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        pass

class Swimmer:
    def swim(self):
        return f'{self.name} плаває!'

class Duck(Animal, Swimmer):
    def speak(self):
        return f'{self.name} каже: Кря-кря!'

duck = Duck("Дональд")
print(duck.speak())  
print(duck.swim())